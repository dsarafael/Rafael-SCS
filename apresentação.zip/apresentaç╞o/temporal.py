import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Criar dados de exemplo
dados = {
    'ano': [2019, 2020, 2021, 2022, 2023, 2024],
    'jan': [25, 26, 24, 27, 28, 26],
    'fev': [26, 27, 25, 28, 29, 27],
    'mar': [28, 29, 27, 30, 31, 29],
    'abr': [30, 31, 29, 32, 33, 31],
    'mai': [32, 33, 31, 34, 35, 33],
    'jun': [33, 34, 32, 35, 36, 34],
    'jul': [34, 35, 33, 36, 37, 35],
    'ago': [34, 35, 33, 36, 37, 35],
    'set': [33, 34, 32, 35, 36, 34],
    'out': [31, 32, 30, 33, 34, 32],
    'nov': [29, 30, 28, 31, 32, 30],
    'dez': [27, 28, 26, 29, 30, 28]
}

# Converter os dados em DataFrame
df = pd.DataFrame(dados)

# Converter o DataFrame de wide para long
df_long = df.melt(id_vars='ano', var_name='mês', value_name='temperatura')

# Plotar o gráfico de linha usando Seaborn
plt.figure(figsize=(12, 6))
sns.lineplot(data=df_long, x='ano', y='temperatura', hue='mês', palette='viridis')
plt.title('Variação da Temperatura ao Longo dos Anos')
plt.xlabel('Ano')
plt.ylabel('Temperatura (°C)')
plt.legend(title='Mês', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()
