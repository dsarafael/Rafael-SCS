import streamlit as st
import pandas as pd
import plotly.express as px

# Carregar os dados
def load_data():
    data = {
        'Data': pd.date_range(start='2020-01-01', periods=12, freq='M'),
        'Vendas': [1000, 1200, 1500, 1800, 2000, 2100, 2200, 2300, 2000, 2700, 3000, 3200]
    }
    df = pd.DataFrame(data)
    return df

# Função para plotar o gráfico de variação ao longo do tempo
def plot_variation(data):
    fig = px.line(data, x='Data', y='Vendas', title='Variação de Vendas ao Longo do Tempo')
    st.plotly_chart(fig)

# Carregar dados
sales_data = load_data()

# Título da aplicação
st.title('Variação ao Longo do Tempo')

# Visualizar os dados
st.subheader('Dados de Vendas Mensais')
st.write(sales_data)

# Plotar o gráfico de variação ao longo do tempo
st.subheader('Gráfico de Variação temporal')
plot_variation(sales_data)
