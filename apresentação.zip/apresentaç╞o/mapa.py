import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

# Criar uma figura e um eixo utilizando a projeção de mapa Mercator
fig = plt.figure(figsize=(10, 6))
ax = fig.add_subplot(1, 1, 1, projection=ccrs.Mercator())

# Adicionar características do mapa, como linhas costeiras e fronteiras políticas
ax.add_feature(cfeature.COASTLINE)
ax.add_feature(cfeature.BORDERS, linestyle=':')

# Adicionar título ao mapa
ax.set_title('Mapa-Mundi com Cartopy')

# Exibir o mapa
plt.show()
