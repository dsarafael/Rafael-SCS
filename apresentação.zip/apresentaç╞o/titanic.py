#streamlit - interface de usuário
import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

@st.cache_data
def load_data():
    data = pd.read_csv("https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv")
    return data

# Função para criar gráfico de contagem de sobreviventes por sexo
def plot_survival_count(data):
    plt.figure(figsize=(8, 6))
    sns.countplot(x='Sex', hue='Survived', data=data, palette='pastel')
    plt.title('Número de Sobreviventes por Sexo')
    plt.xlabel('Sexo')
    plt.ylabel('Contagem')
    plt.legend(labels=['Não Sobreviveu', 'Sobreviveu'], loc='upper right')
    st.pyplot( )

# Carregar dados
data = load_data()

# Título da aplicação
st.title('Análise de Sobreviventes do Titanic')

# Visualizar os primeiros registros do conjunto de dados
st.subheader('Dados do Titanic')
st.write(data.head())

# Gráfico de contagem de sobreviventes por sexo
st.subheader('Gráfico: Número de Sobreviventes por Sexo')
plot_survival_count(data)

# Sumário estatístico dos dados
st.subheader('Sumário Estatístico dos Dados')
st.write(data.describe())

# Filtro de dados por classe
st.sidebar.header('Filtrar por Classe')
classes = st.sidebar.multiselect('Selecione as Classes', sorted(data['Pclass'].unique()))

# Aplicar filtro de classe
filtered_data = data[data['Pclass'].isin(classes)]

# Visualizar os dados filtrados
st.subheader('Dados Filtrados')
st.write(filtered_data)

# Gráfico de contagem de sobreviventes por sexo nos dados filtrados
st.subheader('Gráfico (Filtrado): Número de Sobreviventes por Sexo')
plot_survival_count(filtered_data)
